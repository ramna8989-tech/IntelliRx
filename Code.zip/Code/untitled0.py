import json
import pickle
import os

# Load raw JSON
with open("DrugRec.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# If JSON is dict-like, use items; else enumerate
items = list(data.items()) if isinstance(data, dict) else list(enumerate(data))
n = len(items)

# Split: 80% train, 10% dev, 10% test
train_data = dict(items[:int(0.8*n)])
dev_data = dict(items[int(0.8*n):int(0.9*n)])
test_data = dict(items[int(0.9*n):])

# Output directory
output_dir = "data/DrugRec0716"
os.makedirs(output_dir, exist_ok=True)

# Save splits
with open(os.path.join(output_dir, "train.pkl"), "wb") as f:
    pickle.dump(train_data, f)
with open(os.path.join(output_dir, "dev.pkl"), "wb") as f:
    pickle.dump(dev_data, f)
with open(os.path.join(output_dir, "test.pkl"), "wb") as f:
    pickle.dump(test_data, f)

print("Saved train/dev/test .pkl files in", output_dir)
