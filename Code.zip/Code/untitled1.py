import ijson

path = r"C:\Users\ayada\OneDrive\Desktop\TraceDR-main\TraceDR-main\TraceDR-model\data\DrugRec.json"

with open(path, "rb") as f:
    parser = ijson.items(f, "item")
    first = next(parser)

print(first.keys())

for k,v in first.items():
    print(k, ":", v if len(str(v)) < 200 else str(v)[:200])
